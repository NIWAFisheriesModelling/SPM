//---------------------------------------------------------------------------
//
//                 __________                                      
//    _____   __ __\______   \_____  _______  ______  ____ _______ 
//   /     \ |  |  \|     ___/\__  \ \_  __ \/  ___/_/ __ \\_  __ \ 
//  |  Y Y  \|  |  /|    |     / __ \_|  | \/\___ \ \  ___/ |  | \/
//  |__|_|  /|____/ |____|    (____  /|__|  /____  > \___  >|__|   
//        \/                       \/            \/      \/        
//  (C) 2010 Ingo Berg
//
//  example1.cpp - using the parser as a static library
//
//---------------------------------------------------------------------------

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#define CREATE_LEAKAGE_REPORT

/** \brief This macro will enable mathematical constants like M_PI. */
#define _USE_MATH_DEFINES		

#include <cstdlib>
#include <cstring>
#include <cmath>
#include <string>
#include <iostream>
#include <locale>
#include <limits>
#include <ios> 
#include <iomanip>

#include "mecParserDLL.h"
//#include "mecParser.h"
//#include "mecUnitTest.h"


using namespace std;
using namespace mec;


// Dumping memory leaks in the destructor of the static guard
// guarantees i won't get false positives from the ErrorMsg 
// class wich is a singleton with a static instance.
struct DumpLeaks
{
 ~DumpLeaks()
  {
    _CrtDumpMemoryLeaks();
  }
} static LeakDumper;

// Operator callback functions
value_type Rnd(value_type v) { return v*std::rand()/(value_type)(RAND_MAX+1.0); }
value_type xxx(value_type v) { return v; }
value_type Not(value_type v) { return v==0; }
value_type f3of3(value_type v1, value_type v2, value_type v3) 
{
  return v3;
};

value_type Add(value_type v1, value_type v2) 
{ 
  return v1+v2; 
}

value_type Sub(value_type v1, value_type v2) 
{ 
  return v1-v2; 
}

value_type Mul(value_type v1, value_type v2) { return v1*v2; }

//---------------------------------------------------------------------------
value_type Or(value_type v1, value_type v2)
{
  return v1!=1 || v2!=1;
}

//---------------------------------------------------------------------------
value_type Ping() 
{ 
  console() << "ping\n"; 
  return 0; 
}

//---------------------------------------------------------------------------
// Factory function for creating new parser variables
// This could as well be a function performing database queries.
value_type* AddVariable(const char_type *a_szName, void *a_pUserData)
{
  // I don't want dynamic allocation here, so i used this static buffer
  // If you want dynamic allocation you must allocate all variables dynamically
  // in order to delete them later on. Or you find other ways to keep track of 
  // variables that have been created implicitely.
  static value_type afValBuf[100];  
  static int iVal = 0;          

  console() << _T("Generating new variable \"") 
            << a_szName << _T("\" (slots left: ")
            << 99-iVal << _T(")")
            << _T(" User data pointer is:") 
            << std::hex << a_pUserData <<endl;

  afValBuf[iVal] = 0;
  if (iVal>=99)
    throw ParserError( _T("Variable buffer overflow.") );

  return &afValBuf[iVal++];
}

//---------------------------------------------------------------------------
void Splash()
{
  console() << _T("                 __________                                       \n");
  console() << _T("    _____   __ __\\______   \\_____  _______  ______  ____ _______\n");
  console() << _T("   /     \\ |  |  \\|     ___/\\__  \\ \\_  __ \\/  ___/_/ __ \\\\_  __ \\ \n");
  console() << _T("  |  Y Y  \\|  |  /|    |     / __ \\_|  | \\/\\___ \\ \\  ___/ |  | \\/ \n");
  console() << _T("  |__|_|  /|____/ |____|    (____  /|__|  /____  > \\___  >|__|    \n");
  console() << _T("        \\/                       \\/            \\/      \\/         \n");
  console() << _T("  Version ") << Parser().GetVersion() << _T("\n");
  console() << _T("  (C) 2010 Ingo Berg\n");
}

//---------------------------------------------------------------------------
void SelfTest()
{
  console() << _T( "-----------------------------------------------------------\n");
  console() << _T( "Configuration:\n\n");

#if defined(_DEBUG)
  console() << _T( "- DEBUG build\n");
#else
  console() << _T( "- RELEASE build\n");
#endif

#if defined(_UNICODE)
  console() << _T( "- UNICODE build\n");
#else  
  console() << _T( "- ASCII build\n");
#endif

  console() << _T( "-----------------------------------------------------------\n");
  console() << _T( "Running test suite:\n\n");

#if !defined(MEC_DUMP_STACK) && !defined(MEC_DUMP_CMDCODE)
  Test::UnitTest pt;
  pt.Run();
#else
  console() << _T( "Skipped due to compiling with MEC_DUMP_CMDCODE option\n");
#endif

  console() << _T( "-----------------------------------------------------------\n");
  console() << _T( "Commands:\n\n");
  console() << _T( "  list var     - list parser variables\n");
  console() << _T( "  list exprvar - list expression variables\n");
  console() << _T( "  list const   - list all numeric parser constants\n");
  console() << _T( "  locale de    - switch to german locale\n");
  console() << _T( "  locale en    - switch to english locale\n");
  console() << _T( "  locale reset - reset locale\n");
  console() << _T( "  quit         - exits the parser\n");
  console() << _T( "\nConstants:\n\n");
  console() << _T( "  \"_e\"   2.718281828459045235360287\n");
  console() << _T( "  \"_pi\"  3.141592653589793238462643\n");
  console() << _T( "-----------------------------------------------------------\n");
  console() << _T("\n");
  console() << _T("DISCLAIMER: muParseSSE is EXPERIMENTAL code not meant for production use!\n");
  console() << _T("\n");

}

//---------------------------------------------------------------------------
void ListVar(const ParserBase &parser)
{
  // Query the used variables (must be done after calc)
  varmap_type variables = parser.GetVar();
  if (!variables.size())
    return;

  console() << "\nParser variables:\n";
  console() <<   "-----------------\n";
  console() << "Number: " << (int)variables.size() << "\n";
  varmap_type::const_iterator item = variables.begin();
  for (; item!=variables.end(); ++item)
    console() << _T("Name: ") << item->first << _T("   Address: [0x") << item->second << _T("]\n");
}

//---------------------------------------------------------------------------
void ListConst(const ParserBase &parser)
{
  console() << _T("\nParser constants:\n");
  console() << _T("-----------------\n");

  valmap_type cmap = parser.GetConst();
  if (!cmap.size())
  {
    console() << _T("Expression does not contain constants\n");
  }
  else
  {
    valmap_type::const_iterator item = cmap.begin();
    for (; item!=cmap.end(); ++item)
      console() << _T("  ") << item->first << _T(" =  ") << item->second << _T("\n");
  }
}

//---------------------------------------------------------------------------
void ListExprVar(const ParserBase &parser)
{
  string_type sExpr = parser.GetExpr();
  if (sExpr.length()==0)
  {
    cout << _T("Expression string is empty\n");
    return;
  }

  // Query the used variables (must be done after calc)
  console() << _T("\nExpression variables:\n");
  console() <<   _T("---------------------\n");
  console() << _T("Expression: ") << parser.GetExpr() << _T("\n");

  varmap_type variables = parser.GetUsedVar();
  if (!variables.size())
  {
    console() << _T("Expression does not contain variables\n");
  }
  else
  {
    console() << _T("Number: ") << (int)variables.size() << _T("\n");
    varmap_type::const_iterator item = variables.begin();
    for (; item!=variables.end(); ++item)
      console() << _T("Name: ") << item->first << _T("   Address: [0x") << item->second << _T("]\n");
  }
}

//---------------------------------------------------------------------------
/** \brief Check for external keywords.
*/
int CheckKeywords(const char_type *a_szLine, Parser &a_Parser)
{
  string_type sLine(a_szLine);

  if ( sLine == _T("quit") )
  {
    return -1;
  }
  else if ( sLine == _T("list var") )
  {
    ListVar(a_Parser);
    return 1;
  }
  else if ( sLine == _T("list const") )
  {
    ListConst(a_Parser);
    return 1;
  }
  else if ( sLine == _T("list exprvar") )
  {
    ListExprVar(a_Parser);
    return 1;
  }
  else if ( sLine == _T("list const") )
  {
    ListConst(a_Parser);
    return 1;
  }
  else if ( sLine == _T("locale de") )
  {
    console() << _T("Setting german locale: ArgSep=';' DecSep=',' ThousandsSep='.'\n");
    a_Parser.SetArgSep(';');
    a_Parser.SetDecSep(',');
    a_Parser.SetThousandsSep('.');
    return 1;
  }
  else if ( sLine == _T("locale en") )
  {
    console() << _T("Setting english locale: ArgSep=',' DecSep='.' ThousandsSep=''\n");
    a_Parser.SetArgSep(',');
    a_Parser.SetDecSep('.');
    a_Parser.SetThousandsSep();
    return 1;
  }
  else if ( sLine == _T("locale reset") )
  {
    console() << _T("Resetting locale\n");
    a_Parser.ResetLocale();
    return 1;
  }

  return 0;
}

//---------------------------------------------------------------------------
void Calc()
{
  Parser  parser;

  // Add some variables
  value_type  vVarVal[] = { 1, 2 }; // Values of the parser variables
  parser.DefineVar(_T("a"), &vVarVal[0]);  // Assign Variable names and bind them to the C++ variables
  parser.DefineVar(_T("b"), &vVarVal[1]);

  // Define the variable factory
  parser.SetVarFactory(AddVariable, &parser);

  for(;;)
  {
    try
    {
      string_type sLine;
      std::getline(console_in(), sLine);

      switch (CheckKeywords(sLine.c_str(), parser))
      {
      case  0: break;
      case  1: continue;
      case -1: return;
      }

      if (!sLine.length())
        continue;

      parser.SetExpr(sLine);
      parser.SetParserEngine(peBYTECODE);
      //parser.SetParserEngine(peBYTECODE_ASM);

      console() << std::setprecision(12);

      // The first call to eval implicitely creates the bytecode, and resets
      // an internal pointer to the bytecode parsing function. Next time you call Eval
      // the bytecode is used automatically!
      //console() << "Parsing from string (slow):   " << parser.Eval() << "\n";
      console() << "Parsing from bytecode:        " << parser.Eval() << "\n";

      //exprfun_type ptfun;
      //for (int i=-1; i<=5; ++i)
      //{
      //  ptfun = parser.Compile(1);
      //  console() << "asmjit compiled function result (" << dec << i << ") : " << (*ptfun)() << "\n";
      //}
    }
    catch(ParserError &e)
    {
      console() << _T("\nError:\n");
      console() << _T("------\n");
      console() << _T("Message:     ")   << e.GetMsg()   << _T("\n");
      console() << _T("Expression:  \"") << e.GetExpr()  << _T("\"\n");
      console() << _T("Token:       \"") << e.GetToken()    << _T("\"\n");
      console() << _T("Position:    ")   << (int)e.GetPos() << _T("\n");
      console() << _T("Errc:        ")   << std::dec << e.GetCode() << _T("\n");
    }
  } // while running
}

//---------------------------------------------------------------------------
int main(int, char**)
{
  Splash();
  SelfTest();

  console() << _T("Enter an expression or a command:\n");

  try
  {
    Calc();
  }
  catch(Parser::exception_type &e)
  {
    // Only erros raised during the initialization will end up here
    // formula related errors are treated in Calc()
    console() << _T("Initialization error:  ") << e.GetMsg() << endl;

    string_type sBuf;
    console_in() >> sBuf;
  }
  catch(std::exception & /*exc*/)
  {
    // there is no unicode compliant way to query exc.what()
    // so i'll leave it for this example.
    console() << _T("aborting...\n");
  }

  return 0;
}
