/*
              __________                                   _________ ____________________
   _____  __ _\______   \_____ _______  ______ ___________/   _____//   _____/\_   _____/
  /     \|  |  \     ___/\__  \\_  __ \/  ___// __ \_  __ \_____  \ \_____  \  |    __)_ 
 |  Y Y  \  |  /    |     / __ \|  | \/\___ \\  ___/|  | \/        \/        \ |        \
 |__|_|  /____/|____|    (____  /__|  /____  >\___  >__| /_______  /_______  //_______  /
       \/                     \/           \/     \/             \/        \/         \/ 
 
  Copyright (C) 2010 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/

#include "mecCallback.h"

/** \file
    \brief Implementation of the parser callback class.
*/


namespace mec
{
  //---------------------------------------------------------------------------
  Callback::Callback(fun_type0 a_pFun, int flags)
    :m_pFun((void*)a_pFun)
    ,m_iArgc(0)
    ,m_iPri(-1)
    ,m_iFlags(flags)
    ,m_eOprtAsct(oaNONE)
    ,m_iCode(cmFUNC)
    ,m_iType(tpDBL)
  {}

  //---------------------------------------------------------------------------
  Callback::Callback(fun_type1 a_pFun, int a_iPrec, ECmdCode a_iCode, int flags)
    :m_pFun((void*)a_pFun)
    ,m_iArgc(1)
    ,m_iPri(a_iPrec)
    ,m_iFlags(flags)
    ,m_eOprtAsct(oaNONE)
    ,m_iCode(a_iCode)
    ,m_iType(tpDBL)
  {}


  //---------------------------------------------------------------------------
  /** \brief Constructor for constructing funcstion callbacks taking two arguments. 
      \throw nothrow
  */
  Callback::Callback(fun_type2 a_pFun, int flags)
    :m_pFun((void*)a_pFun)
    ,m_iArgc(2)
    ,m_iPri(-1)
    ,m_iFlags(flags)
    ,m_eOprtAsct(oaNONE)
    ,m_iCode(cmFUNC)
    ,m_iType(tpDBL)
  {}

  //---------------------------------------------------------------------------
  /** \brief Constructor for constructing binary operator callbacks. 
      \param a_pFun Pointer to a static function taking two arguments
      \param a_bAllowOpti A flag indicating this funcation can be optimized
      \param a_iPrec The operator precedence
      \param a_eOprtAsct The operators associativity
      \throw nothrow
  */
  Callback::Callback(fun_type2 a_pFun, 
                                 int a_iPrec, 
                                 EOprtAssociativity a_eOprtAsct, 
                                 int flags)
    :m_pFun((void*)a_pFun)
    ,m_iArgc(2)
    ,m_iPri(a_iPrec)
    ,m_iFlags(flags)
    ,m_eOprtAsct(a_eOprtAsct)
    ,m_iCode(cmOPRT_BIN)
    ,m_iType(tpDBL)
  {}

  //---------------------------------------------------------------------------
  Callback::Callback(fun_type3 a_pFun, int flags)
    :m_pFun((void*)a_pFun)
    ,m_iArgc(3)
    ,m_iPri(-1)
    ,m_iFlags(flags)
    ,m_eOprtAsct(oaNONE)
    ,m_iCode(cmFUNC)
    ,m_iType(tpDBL)
  {}


  //---------------------------------------------------------------------------
  Callback::Callback(fun_type4 a_pFun, int flags)
    :m_pFun((void*)a_pFun)
    ,m_iArgc(4)
    ,m_iPri(-1)
    ,m_iFlags(flags)
    ,m_eOprtAsct(oaNONE)
    ,m_iCode(cmFUNC)
    ,m_iType(tpDBL)
  {}


  //---------------------------------------------------------------------------
  Callback::Callback(fun_type5 a_pFun, int flags)
    :m_pFun((void*)a_pFun)
    ,m_iArgc(5)
    ,m_iPri(-1)
    ,m_iFlags(flags)
    ,m_eOprtAsct(oaNONE)
    ,m_iCode(cmFUNC)
    ,m_iType(tpDBL)
  {}

  //---------------------------------------------------------------------------
  /** \brief Default constructor. 
      \throw nothrow
  */
  Callback::Callback()
    :m_pFun(0)
    ,m_iArgc(0)
    ,m_iPri(-1)
    ,m_iFlags(0)
    ,m_eOprtAsct(oaNONE)
    ,m_iCode(cmUNKNOWN)
    ,m_iType(tpVOID)
  {}

  //---------------------------------------------------------------------------
  /** \brief Copy constructor. 
      \throw nothrow
  */
  Callback::Callback(const Callback &ref)
  {
    m_pFun       = ref.m_pFun;
    m_iArgc      = ref.m_iArgc;
    m_iCode      = ref.m_iCode;
    m_iType      = ref.m_iType;
    m_iPri       = ref.m_iPri;
    m_iFlags     = ref.m_iFlags;
    m_eOprtAsct  = ref.m_eOprtAsct;
  }

  //---------------------------------------------------------------------------
  /** \brief Clone this instance and return a pointer to the new instance. */
  Callback* Callback::Clone() const
  {
    return new Callback(*this);
  }

  //---------------------------------------------------------------------------
  /** \brief Get the callback address for the parser function. 
  
      The type of the address is void. It needs to be recasted according to the
      argument number to the right type.

      \throw nothrow
      \return #pFun
  */
  void* Callback::GetAddr() const 
  { 
    return m_pFun;  
  }

  //---------------------------------------------------------------------------
  /** \brief Return the callback code. */
  ECmdCode  Callback::GetCode() const 
  { 
    return m_iCode; 
  }
  
  //---------------------------------------------------------------------------
  ETypeCode Callback::GetType() const 
  { 
    return m_iType; 
  }

  //---------------------------------------------------------------------------
  /** \brief Return the operator precedence. 
      \throw nothrown

     Only valid if the callback token is an operator token (binary or infix).
  */
  int Callback::GetPri()  const 
  { 
    return m_iPri;  
  }

  //---------------------------------------------------------------------------
  /** \brief Return the operators associativity. 
      \throw nothrown

     Only valid if the callback token is a binary operator token.
  */
  EOprtAssociativity Callback::GetAssociativity() const
  {
    return m_eOprtAsct;
  }

  //---------------------------------------------------------------------------
  /** \brief Returns the number of function Arguments. */
  int Callback::GetArgc() const 
  { 
    return m_iArgc; 
  }
} // namespace mec
