/*
              __________                                   _________ ____________________
   _____  __ _\______   \_____ _______  ______ ___________/   _____//   _____/\_   _____/
  /     \|  |  \     ___/\__  \\_  __ \/  ___// __ \_  __ \_____  \ \_____  \  |    __)_ 
 |  Y Y  \  |  /    |     / __ \|  | \/\___ \\  ___/|  | \/        \/        \ |        \
 |__|_|  /____/|____|    (____  /__|  /____  >\___  >__| /_______  /_______  //_______  /
       \/                     \/           \/     \/             \/        \/         \/ 
 
  Copyright (C) 2010 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/

#include "mecByteCode.h"

#include <cassert>
#include <string>
#include <stack>
#include <vector>
#include <iostream>

#include "mecDef.h"
#include "mecToken.h"
#include "mecError.h"


/** \file
    \brief Implementation of the parser bytecode class.
*/


namespace mec
{
  //---------------------------------------------------------------------------
  /** Bytecode default constructor. */
  ByteCode::ByteCode()
    :m_iStackPos(0)
    ,m_iMaxStackSize(0)
    ,m_vBase()
    ,mc_iSizeVal( std::max( (int)sizeof(value_type)  / (int)sizeof(bytecode_type), 1 ) )
    ,mc_iSizePtr( std::max( (int)sizeof(value_type*) / (int)sizeof(bytecode_type), 1 ) )
    ,mc_iSizeValEntry( 2 + mc_iSizeVal)
  {
    m_vBase.reserve(1000);
  }

  //---------------------------------------------------------------------------
  /** \brief Copy constructor. 
    
      Implemented in Terms of Assign(const ByteCode &a_ByteCode)
  */
  ByteCode::ByteCode(const ByteCode &a_ByteCode)
    :mc_iSizeVal( sizeof(value_type)/sizeof(bytecode_type) )
    ,mc_iSizePtr( sizeof(value_type*) / sizeof(bytecode_type) )
    ,mc_iSizeValEntry( 2 + mc_iSizeVal)
  {
    Assign(a_ByteCode);
  }

  //---------------------------------------------------------------------------
  /** \brief Assignment operator.
    
      Implemented in Terms of Assign(const ByteCode &a_ByteCode)
  */
  ByteCode& ByteCode::operator=(const ByteCode &a_ByteCode)
  {
    Assign(a_ByteCode);
    return *this;
  }

  //---------------------------------------------------------------------------
  /** \brief Store an address in bytecode.
  
      \param a_pAddr Address to be stored.
      \throw nothrow
  */
  void ByteCode::StorePtr(void *a_pAddr)
  {
    for (int i=0; i<mc_iSizePtr; ++i)
      m_vBase.push_back( *( reinterpret_cast<bytecode_type*>(&a_pAddr) + i ) );
  }

  //---------------------------------------------------------------------------
  /** \brief Copy state of another object to this. 
    
      \throw nowthrow
  */
  void ByteCode::Assign(const ByteCode &a_ByteCode)
  {
    if (this==&a_ByteCode)    
      return;

    m_iStackPos = a_ByteCode.m_iStackPos;
    m_vBase = a_ByteCode.m_vBase;
    m_iMaxStackSize = a_ByteCode.m_iMaxStackSize;
  }

  //---------------------------------------------------------------------------
  /** \brief Add a Variable pointer to bytecode. 
      \param a_pVar Pointer to be added.
      \throw nothrow
  */
  void ByteCode::AddVar(value_type *a_pVar)
  {
    m_vBase.push_back( ++m_iStackPos );
    m_vBase.push_back( cmVAR );

    m_iMaxStackSize = std::max(m_iMaxStackSize, (size_t)m_iStackPos);

    StorePtr(a_pVar);

    const int iSize = mc_iSizeVal - mc_iSizePtr;
    assert(iSize>=0);

    // Make sure variable entries have the same size as value entries.
    // (necessary for optimization; fill with zeros)
    for (int i=0; i<iSize; ++i)
      m_vBase.push_back(0);
  }

  //---------------------------------------------------------------------------
  /** \brief Add a Variable pointer to bytecode. 

      Value entries in byte code consist of:
      <ul>
        <li>value array position of the value</li>
        <li>the operator code according to Token::cmVAL</li>
        <li>the value stored in #mc_iSizeVal number of bytecode entries.</li>
      </ul>

      \param a_pVal Value to be added.
      \throw nothrow
  */
  void ByteCode::AddVal(value_type a_fVal)
  {
    m_vBase.push_back( ++m_iStackPos );
    m_vBase.push_back( cmVAL );
    m_iMaxStackSize = std::max(m_iMaxStackSize, (size_t)m_iStackPos);

    for (int i=0; i<mc_iSizeVal; ++i)
      m_vBase.push_back( *(reinterpret_cast<bytecode_type*>(&a_fVal) + i) );
  }

  //---------------------------------------------------------------------------
  /** \brief Add an operator identifier to bytecode. 
    
      Operator entries in byte code consist of:
      <ul>
        <li>value array position of the result</li>
        <li>the operator code according to Token::ECmdCode</li>
      </ul>

      \sa  Token::ECmdCode
  */
  void ByteCode::AddOp(ECmdCode a_Oprt)
  {
    m_vBase.push_back(--m_iStackPos);
    m_vBase.push_back(a_Oprt);
  }

  //---------------------------------------------------------------------------
  void ByteCode::AddFun(ECmdCode a_fun)
  {
    m_vBase.push_back(m_iStackPos);
    m_vBase.push_back(a_fun);
  }

  //---------------------------------------------------------------------------
  /** \brief Add function to bytecode. 

      \param a_iArgc Number of arguments, negative numbers indicate multiarg functions.
      \param a_pFun Pointer to function callback.
  */
  void ByteCode::AddFun(void *a_pFun, int a_iArgc)
  {
    if (a_iArgc>=0)
      m_iStackPos = m_iStackPos - a_iArgc + 1; 
    else
      m_iStackPos = m_iStackPos + a_iArgc + 1; 

    m_iMaxStackSize = std::max(m_iMaxStackSize, (size_t)m_iStackPos);
    m_vBase.push_back(m_iStackPos);
    m_vBase.push_back(cmFUNC);
    m_vBase.push_back(a_iArgc);

    StorePtr(a_pFun);
  }

  //---------------------------------------------------------------------------
  /** \brief Add end marker to bytecode.
      
      \throw nothrow 
  */
  void ByteCode::Finalize()
  {
    m_vBase.push_back(cmEND);	
    m_vBase.push_back(cmEND);	
//    m_vBase.push_back(cmEND);	

    // shrink bytecode vector to fit
    storage_type(m_vBase).swap(m_vBase);
  }

  //---------------------------------------------------------------------------
  /** \brief Get Pointer to bytecode data storage. */
  const bytecode_type* ByteCode::GetRawData() const
  {
    assert(m_vBase.size());
    return &m_vBase[0];
  }


  //---------------------------------------------------------------------------
  std::size_t ByteCode::GetMaxStackSize() const
  {
    return m_iMaxStackSize+1;
  }

  //---------------------------------------------------------------------------
  std::size_t ByteCode::GetBufSize() const
  {
    return m_vBase.size();
  }

  //---------------------------------------------------------------------------
  /** \brief Delete the bytecode. 
  
      \throw nothrow

      The name of this function is a violation of my own coding guidelines
      but this way it's more in line with the STL functions thus more 
      intuitive.
  */
  void ByteCode::clear()
  {
    m_vBase.clear();
    m_iStackPos = 0;
    m_iMaxStackSize = 0;
  }

  //---------------------------------------------------------------------------
  /** \brief Remove a value number of entries from the bytecode. 
    
      \attention Currently I don't test if the entries are really value entries.
  */
  void ByteCode::RemoveValEntries(unsigned a_iNumber)
  {
    unsigned iSize = a_iNumber * mc_iSizeValEntry;   
    assert( m_vBase.size() >= iSize );
    m_vBase.resize(m_vBase.size()-iSize);

    assert(m_iStackPos >= a_iNumber);
    m_iStackPos -= (a_iNumber);
  }

  //---------------------------------------------------------------------------
  /** \brief Dump bytecode (for debugging only!). */
  void ByteCode::AsciiDump()
  {
    if (!m_vBase.size()) 
    {
      console() << "No bytecode available\n";
      return;
    }

    console() << "Entries:" << (int)m_vBase.size() 
              << " (ValSize:" << mc_iSizeVal 
              << " entries, PtrSize:" << mc_iSizePtr 
              << " entries, MapSize:" << sizeof(bytecode_type) 
              << " byte)\n";
    int i = 0;

    while ( i<(int)m_vBase.size() && m_vBase[i] != cmEND)
    {
      console() << "IDX[" << (int)m_vBase[i++] << "]\t";
      switch (m_vBase[i])
      {
        case cmMIN:  console() << "MIN\n"; ++i; break;
        case cmMAX:  console() << "MAX\n"; ++i; break;
        case cmLT:   console() << "LT\n"; ++i; break;
        case cmGT:   console() << "GT\n"; ++i; break;
        case cmLE:   console() << "LE\n"; ++i; break;
        case cmGE:   console() << "GE\n"; ++i; break;
        case cmEQ:   console() << "EQ\n"; ++i; break;
        case cmNEQ:  console() << "NEQ\n"; ++i; break;
        case cmADD:  console() << "ADD\n"; ++i; break;
        case cmSUB:  console() << "SUB\n"; ++i; break;
        case cmMUL:  console() << "MUL\n"; ++i; break;
        case cmDIV:  console() << "DIV\n"; ++i; break;
#ifdef MEC_INTRINSIC_POW
        case cmPOW:  console() << "POW\n"; ++i; break;
#endif
        case cmSIN:  console() << "SIN\n"; ++i; break;
        case cmCOS:  console() << "COS\n"; ++i; break;
        case cmTAN:  console() << "TAN\n"; ++i; break;
        case cmSQRT: console() << "SQRT\n"; ++i; break;

        case cmVAL: console() << "VAL "; ++i;
                    console() << "[" << *( reinterpret_cast<value_type*>(&m_vBase[i]) ) << "]\n";
                    i += mc_iSizeVal;
                    break;

        case cmVAR: console() << "VAR "; ++i;
  	                console() << "[ADDR: 0x" << std::hex << *(value_type**)&m_vBase[i] << "]\n"; 
                    i += mc_iSizePtr;

                    // Variable entries have the same size like value entries
                    // the remaining spave must be skipped
                    i+= std::max(mc_iSizeVal - mc_iSizePtr, 0);
                    break;
      			
        case cmFUNC:
                    console() << "CALL\t"; ++i;
                    console() << "[ARG:" << std::dec << (int)m_vBase[i] << "]"; ++i;
	                  console() << "[ADDR: 0x" << std::hex << *(value_type**)&m_vBase[i] << "]\n"; 
                    i += mc_iSizePtr;
                    break;

        default:    console() << "(unknown code: " << (int)m_vBase[i] << ")\n"; 
                    ++i;	
                    break;
      } // switch cmdCode
    } // while bytecode

    console() << "END" << std::endl;
  }
} // namespace mec
